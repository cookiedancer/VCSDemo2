import greenfoot.*;

/**
 * Write a description of class storage here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class storage extends Actor
{
    /**
     * Act - do whatever the storage wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}


    
//    public void despawnBullet()
//   {
//       if (isAtEdge())
//    {
//        despawnThis();
//        Greenfoot.stop();
 //   }
//    }
//    
//    public void damageAsteroidLarge()
//    {
//        if (isTouching(AsteroidLarge.class))
//    {
//        removeTouching(AsteroidLarge.class);
 //       despawnThis();
//    }
//    }
//    
//    public void damageAsteroidSmall()
//    {
//        if (isTouching(AsteroidSmall.class))
//    {
//        removeTouching(AsteroidSmall.class);
//        despawnThis();
//    }
//   }
//   
//   public void despawnThis()
//   {
//       getWorld().removeObject(this);
//   }
